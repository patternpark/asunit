This build is our most exciting release yet!

We have completely rebuilt the framework from the ground up directly from the 
source code delivered by JUnit.

The new framework no longer has any dependencies on any particular tool chain,
but instead will work with any compliant ActionScript 3.0 compiler.

Simply extract this archive to a folder somewhere on your system and add that folder
to the classpath of an ActionScript project.

To get started and see example code working, create a new ActionScript project in 
Flex Builder 2.0 and instead of using the "default folder location", choose the 
directory that you extracted the zip archive to. Name the project AsUnit.

If you're using Flex Builder 2.0 alpha you can add to your class path as follows:
- Select the new project
- Choose project properties (can press Alt+Enter)
- Choose ActionScript Build Path from the list on the left
- Click "Add Folder" in the Class Path tab
- Browse to the folder where you extracted the zip archive
- Click OK

Please post any questions, issues or concerns to:

asunit-users@lists.sourceforge.net

Thanks for your support!


Luke Bayes & Ali Mills
